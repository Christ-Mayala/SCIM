import React, { useMemo } from 'react';
import { useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import Navbar from '../../components/layout/Navbar';
import AdminHeader from './headers/AdminHeader';

const AppHeader = () => {
  const { user } = useAuth();
  const location = useLocation();

  const isAdminContent = useMemo(() => {
    const p = location.pathname || '';
    if (p.startsWith('/admin')) return true;
    if (user?.role === 'admin' && (p.startsWith('/add-property') || p.startsWith('/edit-property'))) return true;
    return false;
  }, [location.pathname, user?.role]);

  if (isAdminContent) return <AdminHeader />;
  return <Navbar />;
};

export default AppHeader;
