import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, History, User } from 'lucide-react';
import { favoritesAPI, userAPI, formatPrice } from '../../../lib/api';
import { Button } from '../../../components/ui/Button';

const ClientDashboardPage = () => {
  const [favoriteProperties, setFavoriteProperties] = useState([]);
  const [visited, setVisited] = useState([]);

  useEffect(() => {
    const fetchFavs = async () => {
      try {
        const res = await favoritesAPI.getAll();
        const list = Array.isArray(res.data) ? res.data : res.data?.items || [];
        setFavoriteProperties(Array.isArray(list) ? list : []);
      } catch (_) {
        setFavoriteProperties([]);
      }
    };
    fetchFavs();
  }, []);

  useEffect(() => {
    const loadVisited = async () => {
      try {
        const res = await userAPI.getVisited({ limit: 10 });
        const items = res.data?.items || [];
        if (Array.isArray(items) && items.length > 0) {
          setVisited(items);
          return;
        }
      } catch (_) {}

      try {
        const key = 'visitedProperties';
        const data = JSON.parse(localStorage.getItem(key) || '[]');
        setVisited(Array.isArray(data) ? data : []);
      } catch (_) {
        setVisited([]);
      }
    };

    loadVisited();
  }, []);

  return (
    <div className="min-h-screen bg-zinc-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-semibold text-zinc-900">Mon espace</h1>
          <div className="mt-1 text-sm text-zinc-600">Favoris, visites récentes et accès rapide.</div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm ring-1 ring-zinc-200 p-6 mb-8">
          <h2 className="text-lg font-semibold text-zinc-900 mb-4">Actions rapides</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Link to="/favorites">
              <Button variant="outline" className="w-full flex items-center justify-center gap-2">
                <Heart className="w-5 h-5" />
                <span>Mes favoris</span>
              </Button>
            </Link>
            <Link to="/profile">
              <Button variant="outline" className="w-full flex items-center justify-center gap-2">
                <User className="w-5 h-5" />
                <span>Mon profil</span>
              </Button>
            </Link>
            <Link to="/properties">
              <Button className="w-full">Rechercher des biens</Button>
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-2xl shadow-sm ring-1 ring-zinc-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <div className="flex items-center gap-2">
                <Heart className="h-5 w-5 text-blue-primary" />
                <h2 className="text-lg font-semibold text-zinc-900">Mes favoris</h2>
              </div>
              <Link to="/favorites">
                <Button size="sm" variant="outline">Tout voir</Button>
              </Link>
            </div>

            {favoriteProperties.length === 0 ? (
              <div className="text-sm text-zinc-600">Aucun favori pour le moment.</div>
            ) : (
              <div className="space-y-4">
                {favoriteProperties.slice(0, 6).map((p) => (
                  <div key={p._id} className="flex items-center gap-4">
                    <img
                      src={p.images?.[0]?.url || '/placeholder-property.jpg'}
                      alt={p.titre}
                      className="w-16 h-16 rounded-xl object-cover"
                    />
                    <div className="flex-1 min-w-0">
                      <Link to={`/properties/${p._id}`} className="font-medium text-zinc-900 hover:text-blue-primary truncate block">
                        {p.titre}
                      </Link>
                      <div className="text-sm text-zinc-600">{p.ville}</div>
                    </div>
                    <div className="font-semibold text-zinc-900 whitespace-nowrap">{formatPrice(p.prix)}</div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="bg-white rounded-2xl shadow-sm ring-1 ring-zinc-200 p-6">
            <div className="flex items-center gap-2 mb-6">
              <History className="h-5 w-5 text-blue-primary" />
              <h2 className="text-lg font-semibold text-zinc-900">Récemment visités</h2>
            </div>

            {visited.length === 0 ? (
              <div className="text-sm text-zinc-600">Aucun bien visité récemment.</div>
            ) : (
              <div className="space-y-4">
                {visited.slice(0, 6).map((p) => (
                  <div key={p._id} className="flex items-center gap-4">
                    <img
                      src={(p.images?.[0]?.url || p.image) ? (p.images?.[0]?.url || p.image) : '/placeholder-property.jpg'}
                      alt={p.titre}
                      className="w-16 h-16 rounded-xl object-cover"
                    />
                    <div className="flex-1 min-w-0">
                      <Link to={`/properties/${p._id}`} className="font-medium text-zinc-900 hover:text-blue-primary truncate block">
                        {p.titre}
                      </Link>
                      <div className="text-sm text-zinc-600">{p.ville}</div>
                    </div>
                    <div className="font-semibold text-zinc-900 whitespace-nowrap">{formatPrice(p.prix)}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ClientDashboardPage;
