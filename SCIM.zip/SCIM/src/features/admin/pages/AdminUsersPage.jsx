import React, { useEffect, useMemo, useState } from 'react';
import { Search, Shield, Trash2, UserCheck } from 'lucide-react';
import { adminAPI } from '../../../lib/api';
import { Button } from '../../../components/ui/Button';
import LoadingSpinner from '../../../components/ui/LoadingSpinner';

const AdminUsersPage = () => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState('');

  const load = async () => {
    try {
      setLoading(true);
      setError(null);
      const res = await adminAPI.getUsers({ search: search || undefined, page: 1, limit: 50 });
      setItems(Array.isArray(res.data?.users) ? res.data.users : []);
    } catch (e) {
      setError(e?.response?.data?.message || e?.message || 'Erreur');
      setItems([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return items;
    return items.filter((u) => `${u.nom || ''} ${u.name || ''} ${u.email || ''}`.toLowerCase().includes(q));
  }, [items, search]);

  const handleRole = async (id, role) => {
    try {
      await adminAPI.updateUserRole(id, role);
      setItems((prev) => prev.map((u) => (u._id === id ? { ...u, role } : u)));
    } catch (e) {
      alert(e?.response?.data?.message || 'Mise à jour impossible');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('Supprimer cet utilisateur ?')) return;
    try {
      await adminAPI.deleteUser(id);
      setItems((prev) => prev.filter((u) => u._id !== id));
    } catch (e) {
      alert(e?.response?.data?.message || 'Suppression impossible');
    }
  };

  if (loading) {
    return (
      <div className="min-h-[60vh] flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-zinc-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div>
            <h1 className="text-3xl font-semibold text-zinc-900">Utilisateurs</h1>
            <div className="mt-1 text-sm text-zinc-600">Gestion des comptes</div>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="outline" onClick={load}>Rafraîchir</Button>
          </div>
        </div>

        <div className="mt-6 rounded-2xl bg-white p-4 ring-1 ring-zinc-200 shadow-sm">
          <div className="flex items-center gap-2">
            <div className="grid h-9 w-9 place-items-center rounded-xl bg-blue-primary/10 text-blue-primary">
              <Search className="h-4 w-4" />
            </div>
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Rechercher (nom, email)"
              className="h-10 w-full rounded-xl border border-zinc-200 px-4 text-sm outline-none focus:border-blue-primary"
            />
          </div>
        </div>

        {error ? (
          <div className="mt-6 rounded-2xl bg-white p-6 ring-1 ring-red-500/20 text-sm text-red-700">{error}</div>
        ) : null}

        <div className="mt-6 overflow-hidden rounded-2xl bg-white ring-1 ring-zinc-200 shadow-sm">
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-zinc-50 text-zinc-600">
                <tr>
                  <th className="text-left font-medium px-4 py-3">Nom</th>
                  <th className="text-left font-medium px-4 py-3">Email</th>
                  <th className="text-left font-medium px-4 py-3">Rôle</th>
                  <th className="text-right font-medium px-4 py-3">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-100">
                {filtered.map((u) => (
                  <tr key={u._id}>
                    <td className="px-4 py-3 font-medium text-zinc-900">{u.nom || u.name || '—'}</td>
                    <td className="px-4 py-3 text-zinc-700">{u.email}</td>
                    <td className="px-4 py-3">
                      <span className={u.role === 'admin' ? 'text-blue-primary font-semibold' : 'text-zinc-700'}>
                        {u.role}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-2">
                        {u.role !== 'admin' ? (
                          <Button variant="outline" size="sm" onClick={() => handleRole(u._id, 'admin')} className="gap-2">
                            <Shield className="h-4 w-4" />
                            Admin
                          </Button>
                        ) : (
                          <Button variant="outline" size="sm" onClick={() => handleRole(u._id, 'user')} className="gap-2">
                            <UserCheck className="h-4 w-4" />
                            User
                          </Button>
                        )}
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handleDelete(u._id)}
                          className="gap-2 text-red-600 hover:text-red-700 hover:border-red-300"
                        >
                          <Trash2 className="h-4 w-4" />
                          Supprimer
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminUsersPage;
