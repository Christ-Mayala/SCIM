import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';
import * as api from '../lib/api';
import toast from 'react-hot-toast';

const MessageContext = createContext();

export const useMessage = () => {
  const context = useContext(MessageContext);
  if (!context) {
    throw new Error('useMessage must be used within a MessageProvider');
  }
  return context;
};

export const MessageProvider = ({ children }) => {
  const { user } = useAuth();
  const [messages, setMessages] = useState([]);
  const [conversations, setConversations] = useState([]);
  const [currentConversation, setCurrentConversation] = useState(null);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(false);
  const [inboxPage, setInboxPage] = useState(1);
  const [inboxTotalPages, setInboxTotalPages] = useState(1);
  const [convPage, setConvPage] = useState(1);
  const [convTotalPages, setConvTotalPages] = useState(1);
  const [typingFromOther, setTypingFromOther] = useState(false);
  const socketRef = React.useRef(null);
  const typingStopTimeoutRef = React.useRef(null);
  const typingStartTimeoutRef = React.useRef(null);
  const typingActiveRef = React.useRef(false);

  const fetchInbox = async (page = 1, { silent = false } = {}) => {
    if (!user) return;
    try {
      if (!silent) setLoading(true);
      const response = await api.get('/message/inbox', { params: { page, limit: 10 } });
      const threads = response.data?.threads || [];
      const normalized = threads.map(t => ({
        otherUser: t.correspondant,
        lastMessage: t.dernierMessage,
        unreadCount: t.nonLus || 0,
      }));
      setConversations(page === 1 ? normalized : [...conversations, ...normalized]);
      setInboxPage(response.data?.page || page);
      setInboxTotalPages(response.data?.totalPages || 1);
    } catch (error) {
      console.error('Error fetching inbox:', error);
      toast.error('Erreur lors du chargement de la boîte de réception');
    } finally {
      if (!silent) setLoading(false);
    }
  };

  const fetchMessagesWithUser = async (userId, page = 1, { silent = false } = {}) => {
    if (!user) return;
    try {
      if (!silent) setLoading(true);
      const response = await api.get(`/message/${userId}`, { params: { page, limit: 20 } });
      const list = response.data?.messages || response.data || [];
      setMessages(page === 1 ? list : [...list, ...messages]);
      setCurrentConversation(userId);
      setConvPage(response.data?.page || page);
      setConvTotalPages(response.data?.totalPages || 1);
      await markThreadAsRead(userId);
    } catch (error) {
      console.error('Error fetching messages:', error);
      toast.error('Erreur lors du chargement des messages');
    } finally {
      if (!silent) setLoading(false);
    }
  };

  const sendMessage = async (receiverId, content) => {
    if (!user) return { success: false };
    try {
      const response = await api.post(`/message/${receiverId}`, { contenu: content });
      const sent = response.data;
      if (currentConversation === receiverId) {
        setMessages(prev => [...prev, sent]);
      }
      fetchInbox(1, { silent: true });
      toast.success('Message envoyé avec succès');
      return { success: true };
    } catch (error) {
      console.error('Error sending message:', error);
      toast.error("Erreur lors de l'envoi du message");
      return { success: false, error: error.response?.data?.message || 'Erreur inconnue' };
    }
  };

  const contactScim = async (subject, content) => {
    if (!user) return { success: false };
    try {
      const response = await api.post('/message/scim', { sujet: subject, contenu: content });
      toast.success("Message envoyé à l'administration");
      fetchInbox(1, { silent: true });
      return { success: true };
    } catch (error) {
      console.error('Error contacting SCIM:', error);
      toast.error("Erreur lors de l'envoi du message à l'administration");
      return { success: false, error: error.response?.data?.message || 'Erreur inconnue' };
    }
  };

  const fetchUnreadCount = async () => {
    if (!user) return;
    try {
      const response = await api.get('/message/unread');
      setUnreadCount(response.data?.unread || 0);
    } catch (error) {
      console.error('Error fetching unread count:', error);
    }
  };

  const markMessageAsRead = async (messageId) => {
    try {
      await api.patch(`/message/${messageId}/read`);
      setMessages(prev => prev.map(msg => msg._id === messageId ? { ...msg, lu: true } : msg));
      fetchUnreadCount();
    } catch (error) {
      console.error('Error marking message as read:', error);
    }
  };

  const deleteMessage = async (messageId) => {
    try {
      await api.del(`/message/${messageId}`);
      setMessages(prev => prev.filter(m => m._id !== messageId));
      fetchInbox(1, { silent: true });
      fetchUnreadCount();
      toast.success('Message supprimé');
    } catch (error) {
      console.error('Error deleting message:', error);
      toast.error('Suppression impossible');
    }
  };

  const deleteThread = async (userId) => {
    try {
      await api.del(`/message/thread/${userId}`);
      setMessages([]);
      setConversations(prev => prev.filter(conv => conv?.otherUser?._id !== userId));
      if (currentConversation === userId) setCurrentConversation(null);
      fetchUnreadCount();
      toast.success('Conversation supprimée');
    } catch (error) {
      console.error('Error deleting thread:', error);
      toast.error('Suppression de la conversation impossible');
    }
  };

  const markThreadAsRead = async (userId) => {
    try {
      await api.patch(`/message/thread/${userId}/read`);
      setMessages(prev => prev.map(msg => ({ ...msg, lu: true })));
      setConversations(prev => prev.map(conv => (conv?.otherUser?._id === userId ? { ...conv, unreadCount: 0 } : conv)));
      fetchUnreadCount();
    } catch (error) {
      console.error('Error marking thread as read:', error);
    }
  };

  const clearCurrentConversation = () => {
    setCurrentConversation(null);
    setMessages([]);
    setTypingFromOther(false);
    if (typingStopTimeoutRef.current) clearTimeout(typingStopTimeoutRef.current);
    if (typingStartTimeoutRef.current) clearTimeout(typingStartTimeoutRef.current);
    typingActiveRef.current = false;
  };

  const notifyTyping = () => {
    const socket = socketRef.current;
    if (!socket || !currentConversation) return;
    if (typingStopTimeoutRef.current) clearTimeout(typingStopTimeoutRef.current);
    typingStopTimeoutRef.current = setTimeout(() => {
      if (!socketRef.current || !currentConversation) return;
      if (typingActiveRef.current) {
        socketRef.current.emit('typing:stop', { to: currentConversation });
        typingActiveRef.current = false;
      }
    }, 600);
    if (!typingActiveRef.current && !typingStartTimeoutRef.current) {
      typingStartTimeoutRef.current = setTimeout(() => {
        if (!socketRef.current || !currentConversation) return;
        socketRef.current.emit('typing:start', { to: currentConversation });
        typingActiveRef.current = true;
        typingStartTimeoutRef.current = null;
      }, 300);
    }
  };

  const stopTyping = () => {
    const socket = socketRef.current;
    if (!socket || !currentConversation) return;
    if (typingStartTimeoutRef.current) clearTimeout(typingStartTimeoutRef.current);
    if (typingStopTimeoutRef.current) clearTimeout(typingStopTimeoutRef.current);
    if (typingActiveRef.current) {
      socket.emit('typing:stop', { to: currentConversation });
      typingActiveRef.current = false;
    }
  };

  useEffect(() => {
    if (!user) return;
    if (socketRef.current) {
      socketRef.current.disconnect();
      socketRef.current = null;
    }
    import('socket.io-client')
      .then(({ io }) => {
        const base = (import.meta.env.VITE_API_URL || '').replace(/\/api$/, '');
        const token = localStorage.getItem('token');
        const socket = io(base, {
          auth: { token },
          transports: ['websocket'],
          reconnection: true,
          reconnectionAttempts: Infinity,
          reconnectionDelay: 1000,
          reconnectionDelayMax: 60000,
          randomizationFactor: 0.5,
        });
        socketRef.current = socket;
        socket.on('connect', () => {
          const uid = user?._id || user?.id;
          if (uid) socket.emit('join', uid);
        });
        socket.on('message:new', (msg) => {
          const myId = user?._id || user?.id;
          const otherId = msg?.expediteur?._id === myId ? msg?.destinataire?._id : msg?.expediteur?._id;
          if (currentConversation && otherId === currentConversation) {
            setMessages(prev => [...prev, msg]);
            fetchMessagesWithUser(currentConversation, 1, { silent: true });
          } else {
            fetchInbox(1, { silent: true });
            fetchUnreadCount();
          }
        });
        socket.on('thread:read', ({ userId }) => {
          if (currentConversation === userId) {
            setMessages(prev => prev.map(m => ({ ...m, lu: true })));
          } else {
            fetchInbox(1, { silent: true });
          }
        });
        socket.on('message:deleted', ({ id }) => {
          setMessages(prev => prev.filter(m => m._id !== id));
          fetchInbox(1, { silent: true });
        });
        socket.on('thread:deleted', ({ userId }) => {
          setConversations(prev => prev.filter(c => c?.otherUser?._id !== userId));
          if (currentConversation === userId) {
            setCurrentConversation(null);
            setMessages([]);
          }
          fetchUnreadCount();
        });
        socket.on('typing', ({ from, isTyping } = {}) => {
          if (currentConversation && from === currentConversation) {
            setTypingFromOther(Boolean(isTyping));
          }
        });
        return () => {
          if (socketRef.current) socketRef.current.disconnect();
          socketRef.current = null;
        };
      })
      .catch((e) => {
        console.warn('socket.io-client non installé ou erreur d\'import:', e);
      });
  }, [user, currentConversation]);

  useEffect(() => {
    if (user) {
      fetchInbox(1, { silent: true });
      fetchUnreadCount();
    } else {
      setConversations([]);
      setMessages([]);
      setCurrentConversation(null);
      setUnreadCount(0);
      setTypingFromOther(false);
    }
  }, [user]);

  const value = {
    messages,
    conversations,
    currentConversation,
    unreadCount,
    loading,
    fetchInbox,
    fetchMessagesWithUser,
    inboxPage,
    inboxTotalPages,
    convPage,
    convTotalPages,
    sendMessage,
    contactScim,
    fetchUnreadCount,
    markMessageAsRead,
    markThreadAsRead,
    clearCurrentConversation,
    typingFromOther,
    notifyTyping,
    stopTyping,
    deleteMessage,
    deleteThread,
  };

  return (
    <MessageContext.Provider value={value}>
      {children}
    </MessageContext.Provider>
  );
};

export default MessageContext;
